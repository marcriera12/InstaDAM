package com.example.instagram_clone_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
